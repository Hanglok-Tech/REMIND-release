@echo off

REM 创建目录并设置权限
mkdir mongodb\data
mkdir mongodb\log
icacls mongodb\data /grant Everyone:(OI)(CI)F
icacls mongodb\log /grant Everyone:(OI)(CI)F

call:main

REM 检查是否安装了 Docker Compose
:check_docker_compose
  docker compose --version >nul 2>&1
  if %errorlevel% neq 0 (
    echo Docker Compose is not installed. Please install Docker Compose.
    exit /b 1
  )
goto:eof

REM 检查是否存在 docker-compose.yml 文件
:check_compose_file
  if not exist docker-compose.yml (
    echo docker-compose.yml file not found. Please make sure it exists in the current directory.
    exit /b 1
  )
goto:eof

REM 执行 docker-compose up -d 命令启动服务
:start_service
  echo Starting the service...
  docker compose up -d
  echo The service has been started.
goto:eof

REM 主函数
:main
call :check_docker_compose
IF %ERRORLEVEL% NEQ 0 (
  exit /b 1
)
call :check_compose_file
IF %ERRORLEVEL% NEQ 0 (
  exit /b 1
)
call :start_service
IF %ERRORLEVEL% NEQ 0 (
  exit /b 1
)
exit /b
