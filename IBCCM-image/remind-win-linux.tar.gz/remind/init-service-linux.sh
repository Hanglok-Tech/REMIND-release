#!/bin/bash

# 
mkdir mongodb/data
mkdir mongodb/log
chmod 777 mongodb/data
chmod 777 mongodb/log

# 检查是否安装了 Docker Compose
check_docker_compose() {
  if ! command -v docker compose &> /dev/null; then
    echo "Docker Compose is not installed. Please install Docker Compose."
    exit 1
  fi
}

# 检查是否存在 docker-compose.yml 文件
check_compose_file() {
  if [ ! -f "docker-compose.yml" ]; then
    echo "docker-compose.yml file not found. Please make sure it exists in the current directory."
    exit 1
  fi
}

# 执行 docker-compose up -d 命令启动服务
start_service() {
  echo "Starting the service..."
  docker compose up -d
  echo "The service has been started."
}

# 主函数
main() {
  check_docker_compose
  check_compose_file
  start_service
}

main